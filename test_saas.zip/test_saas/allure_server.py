
import os
os.system('python3 -m pytest /Users/apple/python_file/test_saas/Test_case/test_case.py -n auto --alluredir ./report')

