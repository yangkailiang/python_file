import pytest
import pytest_check
import allure
import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from Tools.Dingding import *
from Api.commercial_api import *
from Tools.Mysql import *
from Tools.tools import *
from Tools.Generate_log import *


@allure.feature('测试saas接口')
class Test(object):
    logger = Logger()
    api = Commercial_api(logger)
    test_data = get_test_data(logger)

    @pytest.mark.parametrize('user,pwd', test_data['test_login_ture'][0], ids=test_data['test_login_ture'][1])
    def test_login_ture(self, user, pwd):
        res = self.api.login(user, pwd)
        pytest_check.equal(res['code'], 10000, print(res))
        pytest_check.equal(res['message'], '处理成功')
        Dingding(self.logger).send_dingding_msg('ceshi', 'aaaaa')
        print('===========================================')

    @pytest.mark.parametrize('user,pwd', test_data['test_login_false'][0], ids=test_data['test_login_false'][1])
    def test_login_false(self, user, pwd):
        res = self.api.login(user, pwd)
        pytest_check.equal(res['code'], 20000, print(res))
        pytest_check.equal(res['message'], '账号不存在或登陆密码错误')