import yaml
import requests
import os
import sys
from requests.packages import urllib3
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))


class Commercial_api(object):
    def __init__(self, logger):
        from Tools.tools import open_yml, get_path, get_url
        self.__logger = logger
        self.__config = open_yml(get_path('config'), self.__logger)
        self.__header = dict(open_yml(get_path('token'), self.__logger))['token']
        self.__url = get_url(self.__logger, 'mock')

    # post基类
    def post(self, name, data=None, header=None):
        urllib3.disable_warnings()
        try:
            res = requests.post(self.__url[name], json=data, headers=header, verify=False).json()
            self.__logger.logger.info('接口%s请求成功,返回为：%s' % (name, res))
            return res
        except Exception as e:
            self.__logger.logger.error('接口%s请求失败，原因是：%s' % (name, e))

    # 获取手机验证码
    def get_message(self, phone):
        data = {'phone': phone}
        return self.post('get_message', data)

    # 获取邀请链接
    def get_invitation_url(self):
        return self.post('get_invitation_url')

    # 邀请入驻
    def invitation(self, sale_id, name, contactName, phone):
        data = {
            'saleUserID': sale_id,
            'name': name,
            'contactName': contactName,
            'phone': phone
        }
        return self.post('invitation', data)

    # 获取销售人员信息
    def get_sale(self, invitation_url):
        data = {'u': invitation_url}
        return self.post('get_sale', data)

    # 获取企业信息
    def get_company(self, userid):
        data = {'userId': userid}
        return self.post('get_company', data)

    # 获取用户的应用列表
    def get_app_list(self):
        return self.post('get_app_list')

    # 获取图片验证码
    def get_imgcode(self, phone):
        data = {'phone': phone}
        return self.post('get_imgcode', data)

    # 登陆-短信验证码&图形验证码
    def login(self, user=None, pwd=None, phone=None, msgcode=None, imgcode=None):
        data = {
           'username': user,
           'password': pwd,
           'phone': phone,
           'smsVerificationCode': msgcode,
           'imgVerificationCode': imgcode
        }
        return self.post('login', data)

    # 获取我的订单列表
    def my_order_list(self, token, size, appid, phone):
        data = {
            'pageSize': size,
            'current': 1,
            'appId': appid,
            'phone': phone
        }
        return self.post('my_order_list', data, header=token)

    # 获取可购买的应用报价列表
    def app_price_list(self, token, app_id):
        data = {'appId': app_id}
        return self.post('app_price_list', data, header=token)

    # 获取商品到期时间
    def app_end_time(self, token, app_id):
        data = {'appId': app_id}
        return self.post('app_end_time',  data, header=token)

    # 基础班-购买-续费===》下单
    def app_do_order(self, token, app_id):
        data = {'id': app_id}
        return self.post('app_do_order', data, header=token)

    # 基础班-购买-续费====》支付
    def app_do_pay(self, token, app_id, price):
        data = {'id': app_id, 'actualAmount': price}
        return self.post('app_do_pay', data, header=token)




if __name__ == '__main__':
    from Tools.Generate_log import Logger
    api = Commercial_api(Logger())
    # api.login(17633641290, 'wWr1KC7964')
    print(api.get_message(11))
    # print(api.get_invitation_url())
    # print(api.invitation(1, 'ykl', 'ykll', '111'))
    # print(api.get_sale('aaa'))
    # print(api.get_company(11))
    # print(api.get_app_list())
    # print(api.get_imgcode(1111))
    # print(api.login())
    # print(api.my_order_list({'token':'11'}, 1, 11, 111))
    print(api.app_price_list({'token':'11'}, 11))
    print(api.app_end_time({'token':'11'}, 11))
    print(api.app_do_order({'token':'11'}, 11))
    print(api.app_do_pay({'token':'11'}, 11, 12))
