import os
import yaml


def open_yml(path, log):
    '''
    打开指定的yaml文件
    :param path: 路径（最好是绝对路径）
    :return: 改文件的所有数据，字典形式返回
    '''
    try:
        with open(path,'r',encoding='utf-8') as f:
            return yaml.safe_load(f)
    except Exception as e:
        log.logger.error('打开%s失败,原因是：%s' % (path, e))


def get_path(which):
    if which == 'config':
        return os.path.abspath(os.path.dirname(os.path.dirname(__file__))) + '/Data/config.yaml'
    elif which == 'token':
        return os.path.abspath(os.path.dirname(os.path.dirname(__file__))) + '/Data/token.yaml'
    elif which == 'prod_url':
        return os.path.abspath(os.path.dirname(os.path.dirname(__file__))) + '/Data/url/prod_url.yaml'
    elif which == 'test_url':
        return os.path.abspath(os.path.dirname(os.path.dirname(__file__))) + '/Data/url/test_url.yaml'
    elif which == 'mock_url':
        return os.path.abspath(os.path.dirname(os.path.dirname(__file__))) + '/Data/url/mock_url.yaml'
    elif which == 'test_data':
        return os.path.abspath(os.path.dirname(os.path.dirname(__file__))) + '/Data/test_data.yaml'
    elif which == 'log_path':
        return os.path.abspath(os.path.dirname(os.path.dirname(__file__))) + '/Journal/sys.log'
    else:
        return '未找到该path'


def get_url(logger, environment):
    if environment == 'prod':
        return open_yml(get_path('prod_url'), logger)
    elif environment == 'test':
        return open_yml(get_path('test_url'), logger)
    elif environment == 'mock':
        return open_yml(get_path('mock_url'), logger)


def get_test_data(logger):
    try:
        test_data = open_yml(get_path('test_data'), logger)
        for i in test_data:
            if len(test_data[i][0]) == len(test_data[i][1]):
                logger.logger.info('测试数据读取成功')
                return test_data
            else:
                logger.logger.error('测试数据读取失败，请检查：%s' % i)
                break
    except Exception as e:
        logger.logger.error('测试数据读取失败,原因是：%s' % e)




if __name__ == '__main__':
    # from Tools.Generate_log import *
    # test_data = open_yml(get_path('test_data'), Logger())
    # for i in test_data:
    #     print(i)
    # write_yml('/Users/ykl/test_saas/Data/token.yaml')
    # path = open_yml(get_path('log'))
    # print(path)
    # write_token()
    a = get_test_data()
    print(a)