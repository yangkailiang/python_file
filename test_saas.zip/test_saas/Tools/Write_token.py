import datetime
import requests
import yaml
import os
import sys
from requests.packages import urllib3
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# from Tools.Generate_log import *


class write_token(object):

    def __init__(self, logger):
        from tools import open_yml, get_path
        self.__logger = logger
        self.__config = open_yml(get_path('config'), self.__logger)
        self.__time = datetime.datetime.now()

    def get_token(self, user, pwd):
        try:
            login_data = {'username': user, 'password': pwd}
            urllib3.disable_warnings()
            login = requests.post(self.__config['prod_url'], json=login_data, verify=False).json()
            self.__logger.logger.info('登陆线上成功：%s' % login['code'])
            return login
        except Exception as e:
            self.__logger.logger.error('用户：%s登陆失败，原因是：%s' % (user, e))

    def write(self):
        from Tools.tools import open_yml, get_path
        try:
            old_time = open_yml(get_path('token'), self.__logger)['time']
        except Exception as e:
            old_time = datetime.datetime.now()
            self.__logger.logger.error('获取上次写入时间失败,原因是:%s' % e)
        try:
            if (self.__time - old_time).seconds >= self.__config['time_out'] * 60:
                with open(get_path('token'), 'w', encoding='utf-8') as f:
                    now_token = {'token': {self.__config['token_key']: self.get_token()['data']['token']}}
                    time_now = {'time': self.__time}
                    yaml.dump(now_token, f)
                    yaml.dump(time_now, f)
                    self.__logger.logger.info('token写入成功')
            else:
                self.__logger.logger.info('token还在有效时间')
        except Exception as e:
            self.__logger.logger.error('token写入失败，原因是：%s' % e)




if __name__ == '__main__':
    from Tools.Generate_log import *
    token = write_token(Logger())
    token.write()